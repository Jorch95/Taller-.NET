namespace Aseguradora.Aplicacion.Entidades;
public abstract class Persona{
    public abstract long Dni{get;set;}
    public abstract string Apellido {get;set;}
    public abstract string Nombre {get;set;}
    public abstract string Telefono {get;set;}
}