namespace Aseguradora.Aplicacion.Interfaces;
using Aseguradora.Aplicacion.Entidades;
public interface IRepositorioPoliza{
    void AgregarPoliza( Poliza p);
    Poliza? GetPoliza(int id);
    List<Poliza> ListarPolizas();
    void ModificarPoliza(Poliza p);
    void EliminarPoliza(int idE);
}