namespace Aseguradora.Aplicacion;
public enum TipoCobertura {ResponsabilidadCivil, TodoRiesgo}
